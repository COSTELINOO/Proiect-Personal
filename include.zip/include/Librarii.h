#pragma once
#define NOGDI             
#define NOUSER            
#include <cstring>
#include <string>
#include<cmath>
#include <iostream>
#include <raylib.h>
//#include <windows.h>
#include <fstream>
#include "Arbore.h"
using namespace std;
